﻿using Microsoft.AspNetCore.Identity;

namespace Tecmave.Front.Models
{
    public class Usuario : IdentityUser<int>
    {
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Cedula { get; set; }
        public string Direccion { get; set; }
        public bool NotificacionesActivadas { get; set; } = false;

    }
}